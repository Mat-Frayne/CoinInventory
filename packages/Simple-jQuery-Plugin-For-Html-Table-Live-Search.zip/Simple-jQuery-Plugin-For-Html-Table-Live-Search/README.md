### html-table-search plugin

A jQuery based plugin which adds a search text box above an HTML table in a page which can be used to search in the table rows.

### Features

* Option to allow case-sensitive or insensitive search
* Option to provide values for Search text and input box placeholder
* Called on the table object and returns the table object ultimately

### Sample Usage

* sample-usage.html file contains sample code where it has been used